# Proxy Reverso para ao.goodinternet.org

Usando Caddy e GitHub Actions.